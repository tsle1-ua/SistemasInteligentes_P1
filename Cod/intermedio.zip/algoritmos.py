"""
Algoritmos de satisfacción de restricciones para resolver Sudoku
================================================================

Este módulo implementa tres algoritmos principales:
1. Backtracking: Búsqueda con retroceso
2. Forward Checking: Propagación de restricciones hacia adelante  
3. AC3: Consistencia de arco para reducción de dominios

Autor: [Tu nombre]
Curso: 2024-25
Asignatura: Sistemas Inteligentes
"""

import copy
from sudoku_csp import SudokuCSP

def backtracking(tablero):
    """
    Algoritmo de backtracking para resolver Sudoku
    
    Args:
        tablero (Tablero): Tablero inicial del Sudoku
        
    Returns:
        bool: True si encuentra solución, False en caso contrario
    """
    csp = SudokuCSP(tablero)
    
    def backtrack_recursivo():
        # Si está completo, hemos encontrado la solución
        if csp.esta_completo():
            return True
        
        # Seleccionar variable no asignada
        pos = csp.obtener_variable_no_asignada()
        if pos is None:
            return True
        
        fila, columna = pos
        variable = csp.variables[fila][columna]
        
        # Probar cada valor en el dominio
        for valor in variable.obtener_dominio():
            if csp.es_consistente(fila, columna, valor):
                # Asignar valor
                variable.asignar_valor(valor)
                
                # Llamada recursiva
                if backtrack_recursivo():
                    return True
                
                # Deshacer asignación (backtrack)
                variable.desasignar()
        
        return False
    
    # Ejecutar algoritmo
    if backtrack_recursivo():
        csp.actualizar_tablero()
        return True
    return False


def forward_checking(tablero):
    """
    Algoritmo de Forward Checking para resolver Sudoku
    
    Args:
        tablero (Tablero): Tablero inicial del Sudoku
        
    Returns:
        bool: True si encuentra solución, False en caso contrario
    """
    csp = SudokuCSP(tablero)
    
    def propagar_restricciones(fila, columna, valor):
        """
        Propaga las restricciones eliminando el valor de los dominios
        de las variables relacionadas
        
        Returns:
            list: Lista de cambios realizados para poder revertirlos
        """
        cambios = []
        relacionadas = csp.obtener_variables_relacionadas(fila, columna)
        
        for f, c in relacionadas:
            variable_relacionada = csp.variables[f][c]
            if not variable_relacionada.esta_asignada():
                if variable_relacionada.eliminar_del_dominio(valor):
                    cambios.append((f, c, valor))
        
        return cambios
    
    def revertir_cambios(cambios):
        """
        Revierte los cambios realizados en la propagación
        """
        for fila, columna, valor in cambios:
            csp.variables[fila][columna].restaurar_en_dominio(valor)
    
    def verificar_dominios_vacios():
        """
        Verifica si alguna variable no asignada tiene dominio vacío
        """
        for fila in range(9):
            for columna in range(9):
                variable = csp.variables[fila][columna]
                if not variable.esta_asignada() and variable.dominio_vacio():
                    return True
        return False
    
    def forward_check_recursivo():
        # Si está completo, hemos encontrado la solución
        if csp.esta_completo():
            return True
        
        # Seleccionar variable no asignada (heurística MRV)
        pos = csp.obtener_variable_no_asignada()
        if pos is None:
            return True
        
        fila, columna = pos
        variable = csp.variables[fila][columna]
        
        # Probar cada valor en el dominio
        for valor in variable.obtener_dominio()[:]:  # Copia para evitar modificaciones durante iteración
            if csp.es_consistente(fila, columna, valor):
                # Asignar valor
                variable.asignar_valor(valor)
                
                # Propagar restricciones (forward checking)
                cambios = propagar_restricciones(fila, columna, valor)
                
                # Verificar si algún dominio se quedó vacío
                if not verificar_dominios_vacios():
                    # Llamada recursiva
                    if forward_check_recursivo():
                        return True
                
                # Deshacer asignación y revertir cambios
                variable.desasignar()
                revertir_cambios(cambios)
        
        return False
    
    # Ejecutar algoritmo
    if forward_check_recursivo():
        csp.actualizar_tablero()
        return True
    return False


def ac3(tablero):
    """
    Algoritmo AC3 (Arc Consistency 3) para reducir dominios
    
    Args:
        tablero (Tablero): Tablero inicial del Sudoku
        
    Returns:
        bool: True si el problema es consistente, False si es inconsistente
    """
    csp = SudokuCSP(tablero)
    
    def obtener_arcos():
        """
        Genera todos los arcos (restricciones binarias) del problema
        
        Returns:
            list: Lista de arcos como tuplas ((fila1, col1), (fila2, col2))
        """
        arcos = []
        
        for fila in range(9):
            for columna in range(9):
                relacionadas = csp.obtener_variables_relacionadas(fila, columna)
                for f_rel, c_rel in relacionadas:
                    arcos.append(((fila, columna), (f_rel, c_rel)))
        
        return arcos
    
    def revisar_arco(xi, xj):
        """
        Revisa si el arco (xi, xj) es consistente
        
        Args:
            xi (tuple): Coordenadas de la primera variable
            xj (tuple): Coordenadas de la segunda variable
            
        Returns:
            bool: True si se modificó el dominio de xi
        """
        fi, ci = xi
        fj, cj = xj
        
        variable_i = csp.variables[fi][ci]
        variable_j = csp.variables[fj][cj]
        
        # Si variable_j está asignada
        if variable_j.esta_asignada():
            valor_j = variable_j.valor
            if valor_j in variable_i.dominio and not variable_i.es_fija:
                variable_i.eliminar_del_dominio(valor_j)
                return True
        
        return False
    
    # Algoritmo AC3
    cola_arcos = obtener_arcos()
    
    while cola_arcos:
        xi, xj = cola_arcos.pop(0)
        
        if revisar_arco(xi, xj):
            # Si el dominio de xi está vacío, el problema es inconsistente
            fi, ci = xi
            if csp.variables[fi][ci].dominio_vacio() and not csp.variables[fi][ci].esta_asignada():
                return False
            
            # Añadir todos los arcos (xk, xi) donde xk es vecino de xi
            relacionadas = csp.obtener_variables_relacionadas(fi, ci)
            for fk, ck in relacionadas:
                if (fk, ck) != xj:  # No añadir el arco que acabamos de revisar
                    cola_arcos.append(((fk, ck), xi))
    
    # Actualizar el tablero con los dominios reducidos
    # Solo para variables con dominio de tamaño 1
    variables_resueltas = 0
    for fila in range(9):
        for columna in range(9):
            variable = csp.variables[fila][columna]
            if not variable.esta_asignada() and variable.tamano_dominio() == 1:
                nuevo_valor = variable.dominio[0]
                variable.asignar_valor(nuevo_valor)
                tablero.setCelda(fila, columna, nuevo_valor)
                variables_resueltas += 1
    
    print(f"AC3 completado: {variables_resueltas} variables resueltas mediante reducción de dominios")
    
    return True


def resolver_con_ac3_y_backtracking(tablero):
    """
    Aplica AC3 primero y luego Backtracking
    
    Args:
        tablero (Tablero): Tablero inicial del Sudoku
        
    Returns:
        bool: True si encuentra solución, False en caso contrario
    """
    # Crear copia del tablero para AC3
    tablero_copia = copy.deepcopy(tablero)
    
    # Aplicar AC3
    if not ac3(tablero_copia):
        print("El problema es inconsistente después de AC3")
        return False
    
    # Aplicar Backtracking con dominios reducidos
    return backtracking(tablero_copia)


def resolver_con_ac3_y_forward_checking(tablero):
    """
    Aplica AC3 primero y luego Forward Checking
    
    Args:
        tablero (Tablero): Tablero inicial del Sudoku
        
    Returns:
        bool: True si encuentra solución, False en caso contrario
    """
    # Crear copia del tablero para AC3
    tablero_copia = copy.deepcopy(tablero)
    
    # Aplicar AC3
    if not ac3(tablero_copia):
        print("El problema es inconsistente después de AC3")
        return False
    
    # Aplicar Forward Checking con dominios reducidos
    return forward_checking(tablero_copia)