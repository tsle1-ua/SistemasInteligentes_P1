Práctica 1: Satisfacción de Restricciones - Sudoku
================================================

## Descripción
Implementación de algoritmos de satisfacción de restricciones para resolver Sudokus:
- Backtracking
- Forward Checking  
- AC3 (Arc Consistency 3)

## Archivos del proyecto
- `main.py`: Programa principal con interfaz gráfica
- `tablero.py`: Clase que representa el tablero del Sudoku
- `variable.py`: Clase Variable para cada celda del CSP
- `sudoku_csp.py`: Modelado del problema como CSP
- `algoritmos.py`: Implementación de los tres algoritmos
- `m1.txt`, `m2.txt`: Plantillas de Sudoku

## Instrucciones de uso

### Ejecución del programa
```bash
python main.py [archivo_sudoku.txt]
```

Si no se especifica archivo, carga `m1.txt` por defecto.

### Botones de la interfaz
- **Load**: Carga un archivo de Sudoku
- **BK**: Ejecuta algoritmo Backtracking
- **FC**: Ejecuta algoritmo Forward Checking  
- **AC3**: Ejecuta algoritmo AC3 (reduce dominios)

### Funcionamiento
1. Ejecutar el programa
2. Hacer clic en "Load" para cargar un Sudoku
3. Hacer clic en el algoritmo deseado (BK, FC, o AC3)
4. El algoritmo resolverá el Sudoku y mostrará la solución

### Notas
- Los números en negro son los dados inicialmente
- Los números en gris son los calculados por el algoritmo
- AC3 reduce dominios y puede usarse antes de BK o FC para mejorar rendimiento
- Los tiempos de ejecución se muestran en la consola

## Requisitos
- Python 3.x
- Pygame

Autor: [Tu nombre]
Curso: 2024-25