"""
Modelado del Sudoku como problema de satisfacción de restricciones (CSP)
=======================================================================

Esta clase representa el problema de Sudoku como un CSP con:
- 81 variables (una por celda)
- 27 restricciones (9 filas + 9 columnas + 9 submatrices 3x3)
- Dominios de 1-9 para cada variable

Autor: [Tu nombre]
Curso: 2024-25
Asignatura: Sistemas Inteligentes
"""

import copy
from variable import Variable

class SudokuCSP:
    """
    Clase que representa el problema de satisfacción de restricciones del Sudoku
    """
    
    def __init__(self, tablero):
        """
        Inicializa el CSP del Sudoku
        
        Args:
            tablero (Tablero): Objeto tablero con la configuración inicial
        """
        self.tablero = tablero
        self.variables = []
        self.restricciones = []
        self.inicializar_variables()
        self.generar_restricciones()
    
    def inicializar_variables(self):
        """
        Crea las variables del CSP basadas en el tablero
        """
        self.variables = []
        for fila in range(9):
            fila_variables = []
            for columna in range(9):
                valor = self.tablero.getCelda(fila, columna)
                variable = Variable(fila, columna, valor)
                fila_variables.append(variable)
            self.variables.append(fila_variables)
    
    def generar_restricciones(self):
        """
        Genera todas las restricciones del Sudoku:
        - Fila: no repetir números en la misma fila
        - Columna: no repetir números en la misma columna
        - Submatriz 3x3: no repetir números en la misma submatriz
        """
        self.restricciones = []
        
        # Restricciones de fila
        for fila in range(9):
            restriccion_fila = []
            for columna in range(9):
                restriccion_fila.append((fila, columna))
            self.restricciones.append(restriccion_fila)
        
        # Restricciones de columna
        for columna in range(9):
            restriccion_columna = []
            for fila in range(9):
                restriccion_columna.append((fila, columna))
            self.restricciones.append(restriccion_columna)
        
        # Restricciones de submatriz 3x3
        for bloque_fila in range(3):
            for bloque_columna in range(3):
                restriccion_bloque = []
                for fila in range(bloque_fila * 3, (bloque_fila + 1) * 3):
                    for columna in range(bloque_columna * 3, (bloque_columna + 1) * 3):
                        restriccion_bloque.append((fila, columna))
                self.restricciones.append(restriccion_bloque)
    
    def obtener_variables_relacionadas(self, fila, columna):
        """
        Obtiene todas las variables que están relacionadas con la variable dada
        por las restricciones (misma fila, columna o submatriz)
        
        Args:
            fila (int): Fila de la variable
            columna (int): Columna de la variable
            
        Returns:
            list: Lista de tuplas (fila, columna) de variables relacionadas
        """
        relacionadas = set()
        
        # Variables en la misma fila
        for c in range(9):
            if c != columna:
                relacionadas.add((fila, c))
        
        # Variables en la misma columna
        for f in range(9):
            if f != fila:
                relacionadas.add((f, columna))
        
        # Variables en la misma submatriz 3x3
        bloque_fila = fila // 3
        bloque_columna = columna // 3
        for f in range(bloque_fila * 3, (bloque_fila + 1) * 3):
            for c in range(bloque_columna * 3, (bloque_columna + 1) * 3):
                if f != fila or c != columna:
                    relacionadas.add((f, c))
        
        return list(relacionadas)
    
    def es_consistente(self, fila, columna, valor):
        """
        Verifica si asignar un valor a una variable es consistente
        con las restricciones actuales
        
        Args:
            fila (int): Fila de la variable
            columna (int): Columna de la variable
            valor (str): Valor a verificar
            
        Returns:
            bool: True si la asignación es consistente
        """
        # Verificar fila
        for c in range(9):
            if c != columna and self.variables[fila][c].valor == valor:
                return False
        
        # Verificar columna
        for f in range(9):
            if f != fila and self.variables[f][columna].valor == valor:
                return False
        
        # Verificar submatriz 3x3
        bloque_fila = fila // 3
        bloque_columna = columna // 3
        for f in range(bloque_fila * 3, (bloque_fila + 1) * 3):
            for c in range(bloque_columna * 3, (bloque_columna + 1) * 3):
                if (f != fila or c != columna) and self.variables[f][c].valor == valor:
                    return False
        
        return True
    
    def obtener_variable_no_asignada(self):
        """
        Obtiene la primera variable no asignada usando la heurística MRV
        (Minimum Remaining Values)
        
        Returns:
            tuple: (fila, columna) de la variable no asignada, o None si todas están asignadas
        """
        variable_elegida = None
        min_dominio = 10  # Mayor que el máximo posible
        
        for fila in range(9):
            for columna in range(9):
                variable = self.variables[fila][columna]
                if not variable.esta_asignada():
                    if variable.tamano_dominio() < min_dominio:
                        min_dominio = variable.tamano_dominio()
                        variable_elegida = (fila, columna)
        
        return variable_elegida
    
    def esta_completo(self):
        """
        Verifica si todas las variables están asignadas
        
        Returns:
            bool: True si el CSP está completamente resuelto
        """
        for fila in range(9):
            for columna in range(9):
                if not self.variables[fila][columna].esta_asignada():
                    return False
        return True
    
    def actualizar_tablero(self):
        """
        Actualiza el objeto tablero con los valores actuales de las variables
        """
        for fila in range(9):
            for columna in range(9):
                valor = self.variables[fila][columna].valor
                self.tablero.setCelda(fila, columna, valor)
    
    def imprimir_dominios(self):
        """
        Imprime los dominios de todas las variables para debugging
        """
        print("Dominios de las variables:")
        for fila in range(9):
            for columna in range(9):
                variable = self.variables[fila][columna]
                print(f"({fila},{columna}): {variable.dominio}")